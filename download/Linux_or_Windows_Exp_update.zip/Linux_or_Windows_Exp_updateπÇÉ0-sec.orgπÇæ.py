# !/usr/bin/python
# -*- coding:utf-8 -*-
# __author__:柠檬菠萝
logo = """
****************************************
                                        
   零组（0-SEC.org）提权EXP更新脚本   
    
   Version: v1.0  Author: 柠檬菠萝

****************************************
"""
print(logo)

try:
    import sys
    import requests
    from contextlib import closing
except Exception as e:
    print(e)
    print("请执行命令安装模块:pip install requests")
    sys.exit()

# 文件下载器
def Down_load(file_url, file_path):
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36"
    }
    try:
        with closing(requests.get(file_url, headers=headers, stream=True)) as response:
            chunk_size = 1024  # 单次请求最大值
            with open(file_path, "wb") as file:
                for data in response.iter_content(chunk_size=chunk_size):
                    file.write(data)
    except requests.exceptions.HTTPError:
        print("网络异常请检查。")
        sys.exit()
    except Exception as e:
        print(e)
        sys.exit()


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Help Information：\n")
        print("Python %s [Windows/Linux]\n" % sys.argv[0])
        print("Python %s Linux\n" % sys.argv[0])
        sys.exit()

    linux_kernel_exploits = "http://www.0-sec.org/download/linux.zip"
    windows_kernel_exploits = "http://www.0-sec.org/download/win.zip"
    try:
        if sys.argv[1] in "Linux" or sys.argv[1] in "linux":
            # windows_kernel_exploits = "http://www.0-sec.org/download/win.zip"
            filename = 'linux_kernel_exploits.zip'
            url = linux_kernel_exploits
            print("注：下载速度和网速以及服务器性能有关。")
            print("开始下载Linux提权EXP，请耐心等待。")
            Down_load(linux_kernel_exploits, filename)
            print("下载成功，请见脚本同级目录 %s。" % filename)
            sys.exit()
        elif sys.argv[1] in "Windows" or sys.argv[1] in "windows":
            #linux_kernel_exploits = "http://www.0-sec.org/download/linux.zip"
            filename = 'windows_kernel_exploits.zip'
            url = windows_kernel_exploits
            print("注：下载速度和网速以及服务器性能有关。")
            print("开始下载Windows提权EXP，请耐心等待。")
            Down_load(windows_kernel_exploits, filename)
            print("下载成功，请见脚本同级目录 %s。" % filename)
            sys.exit()
        else:
            print("输入参数有误，请检查。")
            sys.exit()
    except KeyboardInterrupt:
        print("用户已经终止脚本。")
    except Exception as e:
        print(e)
